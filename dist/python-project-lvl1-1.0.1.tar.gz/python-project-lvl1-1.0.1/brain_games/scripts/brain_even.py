#!/usr/bin/env python3

from brain_games.ind_game.even import n_a, manual
from brain_games.general_logic import logic


def main():
    logic(manual, n_a)


if __name__  == '__main__':
    main()

