"""scripts for each game"""
