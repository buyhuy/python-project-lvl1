"""individual logic for each game"""
